﻿namespace Principal.cs
{
    partial class Atividade1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbinicio = new System.Windows.Forms.ComboBox();
            this.cmbfim = new System.Windows.Forms.ComboBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // cmbinicio
            // 
            this.cmbinicio.Font = new System.Drawing.Font("Times New Roman", 18F);
            this.cmbinicio.FormattingEnabled = true;
            this.cmbinicio.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbinicio.Location = new System.Drawing.Point(163, 86);
            this.cmbinicio.Name = "cmbinicio";
            this.cmbinicio.Size = new System.Drawing.Size(106, 35);
            this.cmbinicio.TabIndex = 0;
            this.cmbinicio.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // cmbfim
            // 
            this.cmbfim.Font = new System.Drawing.Font("Times New Roman", 18F);
            this.cmbfim.FormattingEnabled = true;
            this.cmbfim.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbfim.Location = new System.Drawing.Point(420, 86);
            this.cmbfim.Name = "cmbfim";
            this.cmbfim.Size = new System.Drawing.Size(147, 35);
            this.cmbfim.TabIndex = 1;
            this.cmbfim.SelectedIndexChanged += new System.EventHandler(this.cbmfim_SelectedIndexChanged);
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Times New Roman", 18F);
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 27;
            this.listBox1.Location = new System.Drawing.Point(269, 155);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(157, 112);
            this.listBox1.TabIndex = 2;
            // 
            // Atividade1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.cmbfim);
            this.Controls.Add(this.cmbinicio);
            this.Name = "Atividade1";
            this.Text = "Form4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbinicio;
        private System.Windows.Forms.ComboBox cmbfim;
        private System.Windows.Forms.ListBox listBox1;
    }
}