﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Principal.cs
{
    public partial class Atividade1 : Form
    {
        public Atividade1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbmfim_SelectedIndexChanged(object sender, EventArgs e)
        {
            int inicio, fim;
            inicio = int.Parse(cmbinicio.Text);
            fim = int.Parse(cmbfim.Text);
            listBox1.Items.Clear();

            if (inicio <= fim)
            {
                for (int x = inicio; x <= fim; x++)
                { listBox1.Items.Add(x); }


            }
            if (inicio > fim)
            {
                for (int x = inicio; x >= fim; x--)
                { listBox1.Items.Add(x); }

            }
        }

        }
}
