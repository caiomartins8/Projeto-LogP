﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Principal.cs
{
    public partial class Atividade3 : Form
    {
        public Atividade3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double valor;
            valor = 0;
            if (checkBox1.Checked)
            { valor = valor + 20; }
            if (checkBox2.Checked)
            { valor = valor + 10; }
            if (checkBox3.Checked)
            { valor = valor + 5; }
            if (checkBox4.Checked)
            { valor = valor + 25; }
            if (checkBox5.Checked)
            { valor = valor + 15; }
            if (checkBox6.Checked)
            { valor = valor + 20; }
            if (checkBox7.Checked)
            { valor = valor + 8; }
            if (checkBox8.Checked)
            { valor = valor + 30; }

            label11.Text = valor.ToString();

            }
        }
    }
