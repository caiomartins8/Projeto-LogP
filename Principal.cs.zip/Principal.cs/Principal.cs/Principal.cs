﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Principal.cs
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private void exercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // EXERCÍCIO 1 
            Atividade1 ex1 = new Atividade1();
            ex1.ShowDialog();

        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // EXERCÍCIO 2
            Form5 ex2 = new Form5();
            ex2.ShowDialog();
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // EXERCÍCIO 3
            Atividade3 ex3 = new Atividade3();
            ex3.ShowDialog();

        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // EXERCÍCIO 4
            Exercicio4 ex4 = new Exercicio4();
            ex4.ShowDialog();
        }
    }
}
