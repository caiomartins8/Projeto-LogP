﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Principal.cs
{
    public partial class Exercicio4 : Form
    {
        public Exercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                this.BackColor = Color.Blue;
            }
            else if (radioButton2.Checked == true)
            {
                this.BackColor = Color.Yellow;
            }
            else if (radioButton3.Checked == true)
            {
                this.BackColor = Color.Red;
            }
        }
    }
}
